package com.mgexample.bluetooth.remotecontrol

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.graphics.Color
import android.opengl.Visibility
import android.os.Bundle
import android.os.Process
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_main.*
import net.zentring.elevator.Utils.DelayCallback
import net.zentring.elevator.Utils.delay
import java.nio.ByteBuffer
import java.util.*
import kotlin.experimental.xor
import kotlin.system.exitProcess


const val REQUEST_ENABLE_BT = 1
const val AS_UUID_HEAD = "F954"
const val AS_UUID_TAIL = "-91B3-BD9A-F077-80F2A6E57D00"
const val asServiceIdString = AS_UUID_HEAD + "1234" + AS_UUID_TAIL // Service UUID
val asServiceId = UUID.fromString(asServiceIdString)
val asServiceIdArray =
    arrayOf(asServiceId) // varargs argument to scanBleDevices


class MainActivity : AppCompatActivity() {
    private lateinit var connectionObservable: Observable
    lateinit var rxBleDevice: RxBleDevice
    override fun onCreate(savedInstanceState: Bundle?) {
        Settings.MainActivity = this
        val background = Background()
        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)

        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            Toast.makeText(this, R.string.no_bluetooth_sipport, Toast.LENGTH_SHORT).show()


            delay(2, object : DelayCallback {
                override fun afterDelay() {
                    val pid = Process.myPid()
                    Process.killProcess(pid)
                    exitProcess(0)
                }
            })
            //TODO: should close application
        }
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            0
        )

        val rxBleClient = RxBleClientMock.create(applicationContext)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        debug.visibility = View.INVISIBLE
        list.visibility = View.INVISIBLE
        supportActionBar?.hide()
        unlock.setOnSeekBarChangeListener(SeakBarListener(applicationContext))

        val scanSubscription: Disposable = rxBleClient.scanBleDevices(
            ScanSettings.Builder()
                .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES) // change if needed
                .build()
        ).subscribe(
            {
                // Process scan result here.
                debug.setText(it.bleDevice.macAddress.toString() + "\n" + it.bleDevice.name)
            }, {
                debug.setText(it.toString())
                // Handle an error here.
            }
        )
        val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        val pairedDevices =
            mBluetoothAdapter?.bondedDevices

        val s: MutableList<String> = ArrayList()
        if (pairedDevices != null) {
            for (bt in pairedDevices) {
                s.add(bt.name)
            }
            list.adapter =
                ArrayAdapter(
                    this,
                    android.R.layout.simple_list_item_1, pairedDevices.toList()
                )
        }
        if (pairedDevices == null || pairedDevices.size == 0) {

            Toast.makeText(this, "找不到已配對的裝置", Toast.LENGTH_SHORT).show()

            delay(2, object : DelayCallback {
                override fun afterDelay() {
                    val pid = Process.myPid()
                    Process.killProcess(pid)
                    exitProcess(0)
                }
            })
        }
        //val macAddress = "72:BD:CA:D1:F1:91"

        try {
            Toast.makeText(
                this,
                "正在與 " + (pairedDevices?.toList()?.get(0)?.name) + " 連線",
                Toast.LENGTH_SHORT
            ).show()
            rxBleDevice =
                rxBleClient.getBleDevice(pairedDevices?.toList()?.get(0)?.address.toString())
            val disposable = rxBleDevice.establishConnection(false) // <-- autoConnect flag
                .subscribe({ rxBleConnection: RxBleConnection? ->
                    //scanSubscription.dispose()
                    //debug.setText(rxBleDevice.connectionState.toString())
                    Settings.bluetoothConnection = rxBleConnection
                    Log.d("Debug-BT", "BT established")

                    Settings.bluetoothConnection?.readCharacteristic(UUID.fromString("a2b7f090-6c33-4142-85d7-22f0e4e1311b"))
                        ?.subscribe { characteristicValue, error ->
                            readData(characteristicValue)
                        }
                    Settings.device = rxBleDevice
                }, { onConnectionFailure ->
                    Toast.makeText(
                        this,
                        "與 " + (pairedDevices?.toList()?.get(0)?.name) + " 連線失敗",
                        Toast.LENGTH_SHORT
                    ).show()
                    Log.d("Debug-BT", onConnectionFailure?.message.toString())
                })
            // When done... dispose and forget about connection teardown :)
            // But don't call
            // disposable.dispose()
        } catch (e: Exception) {
            //scanSubscription.dispose()
            debug.setText(e.message)
            // handler
        } finally {
            // optional finally block
        }

        // When done, just dispose.
        // scanSubscription.dispose()

        up.setOnClickListener {
            sendData(true)
            arrow(it, "電梯向上")
        }
        down.setOnClickListener {
            sendData(false)
            arrow(it, "電梯向下")
        }
        left.setOnTouchListener(View.OnTouchListener { view, event ->
            floorClick(view, event)
            return@OnTouchListener true
        })
        right.setOnTouchListener(View.OnTouchListener { view, event ->
            floorClick(view, event)
            return@OnTouchListener true
        })

        delay(2, object : DelayCallback {
            override fun afterDelay() {
                background.start()
                //status.text = "無法取得詳細資訊"
            }
        })
    }

    fun sendData(isUp: Boolean? = null) {
        val byteSend = ByteBuffer.allocate(22)
        byteSend.putInt(++Settings.lastTransmitId)
        byteSend.putLong(status.text.toString().toLong())

        var toFloor: Int = 0
        if (isUp == null) {
            toFloor = left.text.toString().toInt() * 10
            toFloor += right.text.toString().toInt()
        }

        byteSend.put(toFloor.toByte())
        if (isUp != null && isUp) {
            byteSend.put(1.toByte())
            byteSend.put(0.toByte())
        } else {
            byteSend.put(0.toByte())
            byteSend.put(1.toByte())
        }
        byteSend.put(0.toByte())
        byteSend.put(0.toByte())
        byteSend.put(0.toByte())
        byteSend.put(0.toByte())
        byteSend.put(0.toByte())
        byteSend.put(0.toByte())

        var checkSum: Byte = 0x7B
        for (i in 0..20) {
            checkSum = checkSum xor byteSend[i]
        }
        byteSend.put(checkSum)
        var byteSendArray: ByteArray = byteArrayOf()
        byteSend.get(byteSendArray, 0, byteSend.capacity());
        Settings.bluetoothConnection?.writeCharacteristic(
            UUID.fromString("a2b7f090-6c33-4142-85d7-22f0e4e1311b"),
            byteSendArray
        )?.subscribe { _ ->
            Toast.makeText(this, "已傳送", Toast.LENGTH_SHORT)
        }
        Settings.bluetoothConnection?.readCharacteristic(UUID.fromString("a2b7f090-6c33-4142-85d7-22f0e4e1311b"))
            ?.subscribe { characteristicValue, error ->
                readData(characteristicValue)
            }
    }

    fun readData(characteristicValue: ByteArray) {
        Log.d("Debug-BT", "BT readed")
        if (characteristicValue.size == 16) {
            //處理電梯送來的資料
            left.text =
                (characteristicValue[12].toInt() / 10).toString()
            right.text =
                (characteristicValue[12].toInt() % 10).toString()
            Settings.floorMax = characteristicValue[13].toInt()
            Settings.floorMin = characteristicValue[14].toInt()


            val byteNumber = ByteBuffer.allocate(4)
            for (i in 0..3) {
                byteNumber.put(i, characteristicValue[i])
            }
            Settings.lastTransmitId = byteNumber.int
            val byteId = ByteBuffer.allocate(8)
            for (i in 4..11) {
                byteId.put(i - 4, characteristicValue[i])
            }
            status.text = byteId.long.toString()
            characteristicValue[0]
            //Log.d("Debug", error.message)
            //Log.d("Debug", byteId.long.toString())
        }
    }

    fun arrow(view: View, text: String) {
        val button = view as ImageView
        if (Settings.isUnlock) {
            Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show()
            button.drawable.setTint(Color.rgb(255, 88, 9))
            delay(2, object : DelayCallback {
                override fun afterDelay() {
                    button.drawable.setTint(Color.BLACK)
                }
            })
        } else {
            Toast.makeText(applicationContext, "請先解鎖", Toast.LENGTH_SHORT).show()
        }
    }

    fun floorClick(view: View, event: MotionEvent) {

        if (Settings.isUnlock) {

            val from = view as TextView

            val x = event.x
            val y = event.y
            var side = -1

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (y < from.height / 2) {
                        side = 1
                    }
                    if (from == left) {
                        Utils.setFloor(
                            (left.text.toString().toInt() + side).toString(),
                            right.text.toString(),
                            side
                        )
                    } else {
                        Utils.setFloor(
                            left.text.toString(),
                            (right.text.toString().toInt() + side).toString(),
                            side
                        )
                    }
                }
            }
        } else {
            Toast.makeText(applicationContext, "請先解鎖", Toast.LENGTH_SHORT).show()
        }
    }
}
